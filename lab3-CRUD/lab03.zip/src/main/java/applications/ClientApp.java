package applications;

public class ClientApp {
    public static void main(String[] args) {
        System.out.println("Client Application Started");
    }
}
