package applications;

public class EmployeeApp {
    public static void main(String[] args) {
        System.out.println("Employee Application Started");
    }
}
