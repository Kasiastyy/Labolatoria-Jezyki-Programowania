package applications;

public class OwnerApp {
    public static void main(String[] args) {
        System.out.println("Owner Application Started");
    }
}
