package applications;

public class CashierApp {
    public static void main(String[] args) {
        System.out.println("Cashier Application Started");
    }
}
