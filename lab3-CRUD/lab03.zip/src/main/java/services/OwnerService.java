package services;

public class OwnerService {
}
