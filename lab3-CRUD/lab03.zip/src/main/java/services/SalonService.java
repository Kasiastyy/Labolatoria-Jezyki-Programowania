package services;

public class SalonService {
}
