package services;

public class CashierService {
}
