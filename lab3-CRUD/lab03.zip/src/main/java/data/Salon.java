package data;

public class Salon {
    protected int id;
    protected String name;
    protected int ownerId;
    protected int workersCount;

    public Salon(int id, String name, int ownerId, int workersCount) {
        this.id = id;
        this.name = name;
        this.ownerId = ownerId;
        this.workersCount = workersCount;
    }

    public int getId() {return id;}
    public String getName() {return name;}
    public int getOwnerId() {return ownerId;}
    public int getWorkersCount() {return workersCount;}
}
