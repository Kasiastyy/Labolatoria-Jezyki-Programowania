package data;

public class Reservation {
}
