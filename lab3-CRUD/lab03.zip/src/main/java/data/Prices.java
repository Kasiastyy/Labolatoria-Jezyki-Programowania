package data;

public class Prices {
    int id;
    String serviceName;
    double price;
}
