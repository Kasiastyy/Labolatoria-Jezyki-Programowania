package data.users;

public class Cashier extends Person{
    public Cashier(int id, int salonId, String name, String role) {
        super(id, salonId, name, "cashier");
    }
}

