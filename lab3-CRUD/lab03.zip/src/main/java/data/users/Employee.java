package data.users;

public class Employee extends Person{
    public Employee(int id, int salonId, String name, String role) {
        super(id, salonId, name, "employee");
    }
}

