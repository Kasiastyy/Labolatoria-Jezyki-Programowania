package data.users;

public class Person {
    protected int id;
    protected int salonId;
    protected String name;
    protected String role;

    public Person(int id, int salonId, String name, String role) {
        this.id = id;
        this.salonId = salonId;
        this.name = name;
        this.role = role;
    }

    public int getId() {return id;}
    public int getSalonId() {return salonId;}
    public String getName() {return name;}
    public String getRole() {return role;}
}

