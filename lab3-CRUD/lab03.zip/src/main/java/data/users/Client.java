package data.users;

public class Client extends Person {
    public Client(int id, int salonId, String name, String role) {
        super(id, salonId, name, "client");
    }
}
