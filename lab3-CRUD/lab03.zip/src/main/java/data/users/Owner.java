package data.users;

public class Owner extends Person {
    public Owner(int id, int salonId, String name, String role) {
        super(0, salonId, name, "owner");

    }
}
