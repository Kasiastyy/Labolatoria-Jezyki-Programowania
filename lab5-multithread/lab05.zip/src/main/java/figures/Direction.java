package figures;

public class Direction {
}
