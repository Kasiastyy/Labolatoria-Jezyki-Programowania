package figures;

public class Pusher {
}
