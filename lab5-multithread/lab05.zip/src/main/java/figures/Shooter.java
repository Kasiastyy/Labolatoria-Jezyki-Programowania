package figures;

public class Shooter {
}
