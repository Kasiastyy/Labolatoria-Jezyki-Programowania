package figures;

public class Figure {
}
