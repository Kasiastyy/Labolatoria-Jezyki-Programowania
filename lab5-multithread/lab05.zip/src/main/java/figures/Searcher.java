package figures;

public class Searcher {
}
