package utils;

public class Treasure {
}
