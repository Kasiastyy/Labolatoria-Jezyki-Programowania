package board;

public class Board {
}
