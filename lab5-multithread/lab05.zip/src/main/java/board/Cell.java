package board;

public class Cell {
}
