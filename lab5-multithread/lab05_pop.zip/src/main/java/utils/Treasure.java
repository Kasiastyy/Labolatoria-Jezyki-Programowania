package utils;

public class Treasure {
    /// placeholder
}
