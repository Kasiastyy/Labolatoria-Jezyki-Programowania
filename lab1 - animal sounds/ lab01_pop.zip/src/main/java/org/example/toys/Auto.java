package org.example.toys;

import org.example.Zabawka;

public class Auto extends Zabawka {
    public Auto() {
        super("Auto", "Brum brum");
    }
}

