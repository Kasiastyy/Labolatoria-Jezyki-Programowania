package org.example.toys;

import org.example.Zabawka;

public class Kot extends Zabawka {
    public Kot() {
        super("Kot", "Miau miau");
    }
}

