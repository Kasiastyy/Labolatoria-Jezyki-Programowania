package org.example.toys;

import org.example.Zabawka;

public class Foka extends Zabawka {
    public Foka() {
        super("Foka", "Auuuu");
    }
}

