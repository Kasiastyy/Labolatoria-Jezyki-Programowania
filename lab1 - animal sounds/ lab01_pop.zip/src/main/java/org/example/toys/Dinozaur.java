package org.example.toys;

import org.example.Zabawka;

public class Dinozaur extends Zabawka {
    public Dinozaur() {
        super("Dinozaur", "AAAAAA");
    }
}

