package org.example.toys;

import org.example.Zabawka;

public class Robot extends Zabawka {
    public Robot() {
        super("Robot", "Bip bip");
    }
}

