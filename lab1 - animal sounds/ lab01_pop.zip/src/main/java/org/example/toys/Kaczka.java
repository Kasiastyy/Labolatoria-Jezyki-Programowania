package org.example.toys;

import org.example.Zabawka;

public class Kaczka extends Zabawka {
    public Kaczka() {
        super("Kaczka", "Kwa kwa");
    }
}

