package org.example.toys;

import org.example.Zabawka;

public class Kogut extends Zabawka {
    public Kogut() {
        super("Kogut", "Kukuryku");
    }
}

