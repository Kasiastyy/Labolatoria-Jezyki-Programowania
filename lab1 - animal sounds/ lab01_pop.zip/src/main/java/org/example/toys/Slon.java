package org.example.toys;

import org.example.Zabawka;

public class Slon extends Zabawka {
    public Slon() {
        super("Słoń", "Prrrrr");
    }
}

