package org.example.toys;

import org.example.Zabawka;

public class Kon extends Zabawka {
    public Kon() {
        super("Koń", "Ihaaa");
    }
}

