package org.example.toys;

import org.example.Zabawka;

public class Samolot extends Zabawka {
    public Samolot() {
        super("Samolot", "Ziuum");
    }
}

